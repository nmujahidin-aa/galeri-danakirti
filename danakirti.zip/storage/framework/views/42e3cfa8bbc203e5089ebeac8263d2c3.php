<?php $__env->startSection('title', 'Contacts'); ?>
<?php $__env->startSection('styles'); ?>
    <link rel="stylesheet" href="<?php echo e(URL::to('/')); ?>/assets/css/contacts2.min.css" />
<?php $__env->stopSection(); ?>
<?php $__env->startSection('data-page', 'contacts2'); ?>
<?php $__env->startSection('data-overlay', '@@overlay'); ?>

<?php $__env->startSection('content'); ?>
<?php if (isset($component)) { $__componentOriginalded7397821bc9484891d9829efda26c3 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalded7397821bc9484891d9829efda26c3 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.templates.user.pages-header','data' => ['title' => 'Hubungi Kami','description' => 'Nibh tellus molestie nunc non blandit. Mi tempus imperdiet nulla malesuada pellentesque elit']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('templates.user.pages-header'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => 'Hubungi Kami','description' => 'Nibh tellus molestie nunc non blandit. Mi tempus imperdiet nulla malesuada pellentesque elit']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalded7397821bc9484891d9829efda26c3)): ?>
<?php $attributes = $__attributesOriginalded7397821bc9484891d9829efda26c3; ?>
<?php unset($__attributesOriginalded7397821bc9484891d9829efda26c3); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalded7397821bc9484891d9829efda26c3)): ?>
<?php $component = $__componentOriginalded7397821bc9484891d9829efda26c3; ?>
<?php unset($__componentOriginalded7397821bc9484891d9829efda26c3); ?>
<?php endif; ?>
<!-- Contacts content start -->
<main>
    <div class="contacts section">
        <div class="container">
            <div class="contacts_map">
                <div id="map"></div>
            </div>
            <ul class="contacts_info d-flex flex-wrap justify-content-between">
                <li class="contacts_info-item col-12 col-md-6 col-lg-3 d-flex flex-column align-items-center" data-order="1">
                    <span class="contacts_info-item_icon d-flex align-items-center justify-content-center">
                        <i class="icon-envelope_open secondary"></i>
                    </span>
                    <h4 class="contacts_info-item_title">Email</h4>
                    <div class="contacts_info-item_main d-flex flex-column align-items-center">
                        <a class="link" href="mailto:example@domain.com">herbalist@cannabis.site</a>
                        <a class="link" href="mailto:example@domain.com">herbalist@test.site</a>
                    </div>
                </li>
                <li class="contacts_info-item col-12 col-md-6 col-lg-3 d-flex flex-column align-items-center" data-order="2">
                    <span class="contacts_info-item_icon d-flex align-items-center justify-content-center">
                        <i class="icon-call secondary"></i>
                    </span>
                    <h4 class="contacts_info-item_title">Phone</h4>
                    <div class="contacts_info-item_main d-flex flex-column align-items-center">
                        <a class="link" href="tel:+1234567890">+1-896-882-3255</a>
                        <a class="link" href="tel:+1234567890">+1-896-882-3255</a>
                    </div>
                </li>
                <li class="contacts_info-item col-12 col-md-6 col-lg-3 d-flex flex-column align-items-center" data-order="3">
                    <span class="contacts_info-item_icon d-flex align-items-center justify-content-center">
                        <i class="icon-location secondary"></i>
                    </span>
                    <h4 class="contacts_info-item_title">Location</h4>
                    <div class="contacts_info-item_main d-flex flex-column align-items-center">
                        <span>211 Lehner Valleys Apt.</span>
                        <span>287 Harrisstad</span>
                    </div>
                </li>
                <li class="contacts_info-item col-12 col-md-6 col-lg-3 d-flex flex-column align-items-center" data-order="4">
                    <span class="contacts_info-item_icon d-flex align-items-center justify-content-center">
                        <i class="icon-clock secondary"></i>
                    </span>
                    <h4 class="contacts_info-item_title">Open Hours</h4>
                    <div class="contacts_info-item_main d-flex flex-column align-items-center">
                        <span>9:00 am to 5:00 pm</span>
                        <span>Monday to Saturday</span>
                    </div>
                </li>
            </ul>
        </div>
    </div>
</main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Laravel\danakirti\resources\views/pages/user/company/contact.blade.php ENDPATH**/ ?>