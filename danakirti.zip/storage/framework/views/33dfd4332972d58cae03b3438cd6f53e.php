<script src="<?php echo e(URL::to('/')); ?>/assets/js/index.min.js"></script>
<?php /**PATH D:\Laravel\danakirti\resources\views/components/templates/user/script.blade.php ENDPATH**/ ?>