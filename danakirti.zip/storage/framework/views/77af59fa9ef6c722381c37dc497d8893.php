<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0, minimum-scale=1.0" />
    <meta http-equiv="X-UA-Compatible" content="ie=edge" />
    <title><?php echo $__env->yieldContent('title'); ?></title>
    <link rel="stylesheet preload" as="style" href="<?php echo e(URL::to('/')); ?>/assets/css/preload.min.css" />
    <link rel="stylesheet preload" as="style" href="<?php echo e(URL::to('/')); ?>/assets/css/icomoon.css" />
    <link rel="stylesheet preload" as="style" href="<?php echo e(URL::to('/')); ?>/assets/css/libs.min.css" />

    <link rel="stylesheet" href="<?php echo e(URL::to('/')); ?>/assets/css/index.min.css" />

    <?php echo $__env->yieldContent('styles'); ?>
</head>
<?php /**PATH D:\Laravel\danakirti\resources\views/components/templates/user/head.blade.php ENDPATH**/ ?>