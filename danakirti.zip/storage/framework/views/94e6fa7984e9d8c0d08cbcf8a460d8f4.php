<!DOCTYPE html>
<html lang="en">
    <?php if (isset($component)) { $__componentOriginal80729f59d74fea24f6c1770d3fc18627 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal80729f59d74fea24f6c1770d3fc18627 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.templates.user.head','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('templates.user.head'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal80729f59d74fea24f6c1770d3fc18627)): ?>
<?php $attributes = $__attributesOriginal80729f59d74fea24f6c1770d3fc18627; ?>
<?php unset($__attributesOriginal80729f59d74fea24f6c1770d3fc18627); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal80729f59d74fea24f6c1770d3fc18627)): ?>
<?php $component = $__componentOriginal80729f59d74fea24f6c1770d3fc18627; ?>
<?php unset($__componentOriginal80729f59d74fea24f6c1770d3fc18627); ?>
<?php endif; ?>
    <body>
    <?php echo $__env->make('sweetalert::alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php if (isset($component)) { $__componentOriginal509c2b9b7614d9b2ce90d6a5f991b22a = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal509c2b9b7614d9b2ce90d6a5f991b22a = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.templates.user.navbar','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('templates.user.navbar'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal509c2b9b7614d9b2ce90d6a5f991b22a)): ?>
<?php $attributes = $__attributesOriginal509c2b9b7614d9b2ce90d6a5f991b22a; ?>
<?php unset($__attributesOriginal509c2b9b7614d9b2ce90d6a5f991b22a); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal509c2b9b7614d9b2ce90d6a5f991b22a)): ?>
<?php $component = $__componentOriginal509c2b9b7614d9b2ce90d6a5f991b22a; ?>
<?php unset($__componentOriginal509c2b9b7614d9b2ce90d6a5f991b22a); ?>
<?php endif; ?>
        <!-- Homepage content start -->
        <main>
            <?php echo $__env->yieldContent('content'); ?>
        </main>
        <!-- Homepage content end -->
        <?php if (isset($component)) { $__componentOriginal075cca6f54a10f0dc03c91d14cda7647 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal075cca6f54a10f0dc03c91d14cda7647 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.templates.user.footer','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('templates.user.footer'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal075cca6f54a10f0dc03c91d14cda7647)): ?>
<?php $attributes = $__attributesOriginal075cca6f54a10f0dc03c91d14cda7647; ?>
<?php unset($__attributesOriginal075cca6f54a10f0dc03c91d14cda7647); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal075cca6f54a10f0dc03c91d14cda7647)): ?>
<?php $component = $__componentOriginal075cca6f54a10f0dc03c91d14cda7647; ?>
<?php unset($__componentOriginal075cca6f54a10f0dc03c91d14cda7647); ?>
<?php endif; ?>
        <script src="<?php echo e(URL::to('/')); ?>/assets/js/common.min.js"></script>
        <div class="cartOffcanvas offcanvas offcanvas-end" tabindex="-1" id="cartOffcanvas">
            <div class="cartOffcanvas_header d-flex align-items-center justify-content-between">
                <h2 class="cartOffcanvas_header-title" id="cartOffcanvasLabel">Cart</h2>
                <button class="cartOffcanvas_header-close" type="button" data-bs-dismiss="offcanvas" aria-label="Close">
                    <i class="icon-close"></i>
                </button>
            </div>
            <div class="cartOffcanvas_body">
                <ul class="cartOffcanvas_body-list">
                    <li class="cartOffcanvas_body-list_item d-sm-flex align-items-center">
                        <div class="media">
                            <a href="product.html" target="_blank" rel="noopener norefferer">
                                <picture>
                                    <source data-srcset="<?php echo e(URL::to('/')); ?>/assets/img/placeholder.jpg" srcset="<?php echo e(URL::to('/')); ?>/assets/img/placeholder.jpg" type="image/webp" />
                                    <img class="lazy" data-src="<?php echo e(URL::to('/')); ?>/assets/img/placeholder.jpg" src="<?php echo e(URL::to('/')); ?>/assets/img/placeholder.jpg" alt="media" />
                                </picture>
                            </a>
                        </div>
                        <div class="main d-flex flex-wrap justify-content-between align-items-end align-items-lg-center">
                            <a class="main_title" href="product.html" target="_blank" rel="noopener norefferer">
                                <span class="main_title-product"> Jonny Chronic - French Macaroon </span>
                            </a>
                            <div class="main_price">
                                <span class="price">$14.98</span>
                            </div>
                            <div class="qty d-flex align-items-center justify-content-between">
                                <span class="qty_minus control disabled d-flex align-items-center">
                                    <i class="icon-minus"></i>
                                </span>
                                <input class="qty_amount" type="number" readonly value="1" min="1" max="99" />
                                <span class="qty_plus control d-flex align-items-center">
                                    <i class="icon-plus"></i>
                                </span>
                            </div>
                            <a class="btn--underline" href="#">Remove</a>
                        </div>
                    </li>
                    <li class="cartOffcanvas_body-list_item d-sm-flex align-items-center">
                        <div class="media">
                            <a href="product.html" target="_blank" rel="noopener norefferer">
                                <picture>
                                    <source data-srcset="<?php echo e(URL::to('/')); ?>/assets/img/placeholder.jpg" srcset="<?php echo e(URL::to('/')); ?>/assets/img/placeholder.jpg" type="image/webp" />
                                    <img class="lazy" data-src="<?php echo e(URL::to('/')); ?>/assets/img/placeholder.jpg" src="<?php echo e(URL::to('/')); ?>/assets/img/placeholder.jpg" alt="media" />
                                </picture>
                            </a>
                        </div>
                        <div class="main d-flex flex-wrap justify-content-between align-items-end align-items-lg-center">
                            <a class="main_title" href="product.html" target="_blank" rel="noopener norefferer">
                                <span class="main_title-product"> House Shatter – Durban Poison </span>
                            </a>
                            <div class="main_price">
                                <span class="price">$6.96</span>
                            </div>
                            <div class="qty d-flex align-items-center justify-content-between">
                                <span class="qty_minus control disabled d-flex align-items-center">
                                    <i class="icon-minus"></i>
                                </span>
                                <input class="qty_amount" type="number" readonly value="1" min="1" max="99" />
                                <span class="qty_plus control d-flex align-items-center">
                                    <i class="icon-plus"></i>
                                </span>
                            </div>
                            <a class="btn--underline" href="#">Remove</a>
                        </div>
                    </li>
                    <li class="cartOffcanvas_body-list_item d-sm-flex align-items-center">
                        <div class="media">
                            <a href="product.html" target="_blank" rel="noopener norefferer">
                                <picture>
                                    <source data-srcset="<?php echo e(URL::to('/')); ?>/assets/img/placeholder.jpg" srcset="<?php echo e(URL::to('/')); ?>/assets/img/placeholder.jpg" type="image/webp" />
                                    <img class="lazy" data-src="<?php echo e(URL::to('/')); ?>/assets/img/placeholder.jpg" src="<?php echo e(URL::to('/')); ?>/assets/img/placeholder.jpg" alt="media" />
                                </picture>
                            </a>
                        </div>
                        <div class="main d-flex flex-wrap justify-content-between align-items-end align-items-lg-center">
                            <a class="main_title" href="product.html" target="_blank" rel="noopener norefferer">
                                <span class="main_title-product"> Natures: CBD Tincture </span>
                            </a>
                            <div class="main_price">
                                <span class="price">$7.49</span>
                            </div>
                            <div class="qty d-flex align-items-center justify-content-between">
                                <span class="qty_minus control disabled d-flex align-items-center">
                                    <i class="icon-minus"></i>
                                </span>
                                <input class="qty_amount" type="number" readonly value="1" min="1" max="99" />
                                <span class="qty_plus control d-flex align-items-center">
                                    <i class="icon-plus"></i>
                                </span>
                            </div>
                            <a class="btn--underline" href="#">Remove</a>
                        </div>
                    </li>
                </ul>
                <div class="cartOffcanvas_body-total d-flex justify-content-between align-items-center">
                    <span>Total</span>
                    <span class="cartTotal">$29.43</span>
                </div>
                <a class="cartOffcanvas_body-btn btn" href="cart.html">Proceed to checkout</a>
            </div>
        </div>
        <?php if (isset($component)) { $__componentOriginal7c17540491b439a07152c50452fbfb1f = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal7c17540491b439a07152c50452fbfb1f = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.templates.user.script','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('templates.user.script'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal7c17540491b439a07152c50452fbfb1f)): ?>
<?php $attributes = $__attributesOriginal7c17540491b439a07152c50452fbfb1f; ?>
<?php unset($__attributesOriginal7c17540491b439a07152c50452fbfb1f); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal7c17540491b439a07152c50452fbfb1f)): ?>
<?php $component = $__componentOriginal7c17540491b439a07152c50452fbfb1f; ?>
<?php unset($__componentOriginal7c17540491b439a07152c50452fbfb1f); ?>
<?php endif; ?>
    </body>
</html>
<?php /**PATH D:\Laravel\danakirti\resources\views/layouts/app.blade.php ENDPATH**/ ?>