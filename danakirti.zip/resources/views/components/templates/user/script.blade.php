<script src="{{URL::to('/')}}/assets/js/index.min.js"></script>
